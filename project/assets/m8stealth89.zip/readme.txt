﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by “trash80”*.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/2296206

*NOTE: “m8stealth89” was originally cloned (copied) from the FontStruction
“m8stealth78” (https://fontstruct.com/fontstructions/show/2289252) by
“trash80”, which is licensed under a Creative Commons Attribution Share
Alike license (http://creativecommons.org/licenses/by-sa/3.0/).
“m8stealth78” was in turn cloned (copied) from the FontStruction
“m8stealth88” (https://fontstruct.com/fontstructions/show/2289177) by
“trash80”, which is licensed under a Creative Commons Attribution Share
Alike license (http://creativecommons.org/licenses/by-sa/3.0/).
“m8stealth88” was in turn cloned (copied) from the FontStruction “m8 8x9
rounded” (https://fontstruct.com/fontstructions/show/2278437) by
“trash80”, which is licensed under a Creative Commons Attribution Share
Alike license (http://creativecommons.org/licenses/by-sa/3.0/).
“m8 8x9 rounded” was in turn cloned (copied) from the FontStruction “m8
8x9 rounded” (https://fontstruct.com/fontstructions/show/2278271) by Matthias
Tellen, which is licensed under a Creative Commons Attribution Share Alike
license (http://creativecommons.org/licenses/by-sa/3.0/).
“m8 8x9 rounded” was in turn cloned (copied) from the FontStruction “m8
8x9 square” (https://fontstruct.com/fontstructions/show/2278180) by Matthias
Tellen, which is licensed under a Creative Commons Attribution Share Alike
license (http://creativecommons.org/licenses/by-sa/3.0/).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2023-2024 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
